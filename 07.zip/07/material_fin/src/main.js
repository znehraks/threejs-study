import example from './ex01';
// import example from './ex02';
// import example from './ex03';
// import example from './ex04';
// import example from './ex05';
// import example from './ex06';
// import example from './ex07';
// import example from './ex08';
// import example from './ex09';
// import example from './ex10';
// import example from './ex11';
// import example from './ex12';
// import example from './ex13';
// import example from './ex14';
// import example from './ex15';
// import example from './ex16';
// import example from './ex17';

example();
