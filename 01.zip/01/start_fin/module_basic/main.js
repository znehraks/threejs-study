// import { hello1, hello2 } from './hello.js';
import * as hell from './hello.js';
// import hello1 from './hello.js';


hell.hello1();
hell.hello2();
// hello1();