// export default function hello1() {
// 	console.log('Hello 1!');
// }
export function hello1() {
	console.log('Hello 1!');
}

export function hello2() {
	console.log('Hello 2!');
}
